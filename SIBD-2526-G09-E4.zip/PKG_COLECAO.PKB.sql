-- ----------------------------------------------------------------------------
--
-- LEI - Etapa 4 do projeto - SIBD - 2025/26 - Grupo 09
--
-- Nuno Nunes - nº63731 - TP12
-- Dinis Fernandes - nº63787 - TP14
-- Tiago Wu - nº63696 - TP14
--
-- ----------------------------------------------------------------------------

CREATE OR REPLACE PACKAGE BODY pkg_colecao IS

    FUNCTION existe_artista (
        isni_in IN artista.isni%TYPE)
        RETURN BOOLEAN
    IS
        c_artista NUMBER;
    BEGIN
        IF isni_in IS NULL THEN
            RETURN FALSE;
        END IF;

        SELECT COUNT(*) INTO c_artista
        FROM artista
        WHERE isni = isni_in;

        RETURN c_artista > 0;
    END existe_artista;

    FUNCTION existe_utilizador (
        username_in IN utilizador.username%TYPE)
        RETURN BOOLEAN
    IS
        c_utilizador NUMBER;
    BEGIN
        IF username_in IS NULL THEN
            RETURN FALSE;
        END IF;

        SELECT COUNT(*) INTO c_utilizador
        FROM utilizador
        WHERE username = username_in;

        RETURN c_utilizador > 0;
    END existe_utilizador;

    FUNCTION existe_album (
        ean_in IN album.ean%TYPE)
        RETURN BOOLEAN
    IS
        c_album NUMBER;
    BEGIN
        IF ean_in IS NULL THEN
            RETURN FALSE;
        END IF;

        SELECT COUNT(*) INTO c_album
        FROM album
        WHERE ean = ean_in;

        RETURN c_album > 0;
    END existe_album;

    FUNCTION posses_utilizador (
        utilizador_in IN possui.utilizador%TYPE)
        RETURN NUMBER
    IS
        c_possui NUMBER;
    BEGIN
        SELECT COUNT(*) INTO c_possui 
        FROM possui
        WHERE utilizador = utilizador_in;  

        RETURN c_possui;
    END posses_utilizador;

    -- ----------------------------------------------------------------------------------------------

    PROCEDURE regista_artista(
        isni_in     IN artista.isni%TYPE, 
        nome_in     IN artista.nome%TYPE, 
        inicio_in   IN artista.inicio%TYPE)
    IS
        excecao_nome_null EXCEPTION;
        excecao_inicio_null EXCEPTION;
        excecao_isni_null EXCEPTION;
    BEGIN
        IF nome_in IS NULL THEN
            RAISE excecao_nome_null;
        ELSIF inicio_in IS NULL THEN
            RAISE excecao_inicio_null;
        ELSIF isni_in IS NULL THEN
            RAISE excecao_isni_null;
        END IF;

        -- Caso as entradas sejam válidas é criado o artista com isni: isni_in
        INSERT INTO artista (isni, nome, inicio)
            VALUES (isni_in, nome_in, inicio_in);
            
    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            RAISE_APPLICATION_ERROR(-20000, 'Já existe um artista com código ISNI ' || isni_in);
            
        WHEN excecao_nome_null THEN
            RAISE_APPLICATION_ERROR(-20001, 'O nome do artista é obrigatório');
        WHEN excecao_inicio_null THEN
            RAISE_APPLICATION_ERROR(-20002, 'O ano de inicio de atividade do artista é obrigatório');
        WHEN excecao_isni_null THEN
            RAISE_APPLICATION_ERROR(-20003, 'O código ISNI do artista é obrigatório');
            
        WHEN OTHERS THEN
            IF (SQLCODE = -2290) THEN
                IF SQLERRM LIKE '%CK_ARTISTA_ISNI%' THEN
                    RAISE_APPLICATION_ERROR(-20004, 'O código ISNI do artista deve ter exatamente 16 caracteres, ' ||
                                                    'sendo composto por 15 dígitos numéricos seguidos por um dígito ou a letra X');
                ELSIF SQLERRM LIKE '%CK_ARTISTA_INICIO%' THEN
                    RAISE_APPLICATION_ERROR(-20005, 'O ano de início de atividade do artista tem de ser positivo');
                END IF;
            ELSE
                DBMS_OUTPUT.PUT_LINE('Erro inesperado: ' || SQLERRM);
                RAISE; 
            END IF;
    END regista_artista;

    -- ----------------------------------------------------------------------------------------------

    PROCEDURE regista_album(
        ean_in      IN album.ean%TYPE, 
        titulo_in   IN album.titulo%TYPE, 
        tipo_in     IN album.tipo%TYPE, 
        ano_in      IN album.ano%TYPE, 
        artista_in  IN album.artista%TYPE, 
        suporte_in  IN album.suporte%TYPE, 
        versao_in   IN album.versao%TYPE := NULL)
    IS
        inicio_artista artista.inicio%TYPE;
        excecao_inicio_atividade EXCEPTION;
        excecao_nao_artista EXCEPTION;

        excecao_ean_null EXCEPTION;
        excecao_titulo_null EXCEPTION;
        excecao_tipo_null EXCEPTION;
        excecao_ano_null EXCEPTION;
        excecao_artista_null EXCEPTION;
        excecao_suporte_null EXCEPTION;
    BEGIN
        IF ean_in IS NULL THEN
            RAISE excecao_ean_null;
        ELSIF titulo_in IS NULL THEN
            RAISE excecao_titulo_null;
        ELSIF tipo_in IS NULL THEN 
            RAISE excecao_tipo_null;
        ELSIF ano_in IS NULL THEN 
            RAISE excecao_ano_null;
        ELSIF artista_in IS NULL THEN 
            RAISE excecao_artista_null;
        ELSIF suporte_in IS NULL THEN 
            RAISE excecao_suporte_null;
        END IF;

        IF NOT existe_artista(artista_in) THEN
            RAISE excecao_nao_artista;
        END IF;
        
        SELECT inicio INTO inicio_artista
        FROM artista
        WHERE isni = artista_in;
        
        -- Verifica se o ano do álbum é posterior ao ano de início de atividade do artista
        IF (ano_in < inicio_artista) THEN
            RAISE excecao_inicio_atividade;
        END IF;
        
        INSERT INTO album (ean, titulo, tipo, ano, artista, suporte, versao)
            VALUES (ean_in, titulo_in, tipo_in, ano_in, artista_in, suporte_in, versao_in);

    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            RAISE_APPLICATION_ERROR(-20006, 'Já existe um álbum com EAN ' || ean_in);
        WHEN excecao_inicio_atividade THEN 
            RAISE_APPLICATION_ERROR(-20007, 'O ano de lançamento do álbum tem de ser posterior ou igual ao ano de início de atividade do artista que o interpreta');
        WHEN excecao_nao_artista THEN
            RAISE_APPLICATION_ERROR(-20008, 'Não foram encontrados artistas com código ISNI ' || artista_in);           

        WHEN excecao_ean_null THEN
            RAISE_APPLICATION_ERROR(-20009, 'O código EAN-13 do álbum é obrigatório');
        WHEN excecao_titulo_null THEN
            RAISE_APPLICATION_ERROR(-20010, 'O título do álbum é obrigatório');
        WHEN excecao_tipo_null THEN
            RAISE_APPLICATION_ERROR(-20011, 'O tipo do álbum é obrigatório');
        WHEN excecao_ano_null THEN
            RAISE_APPLICATION_ERROR(-20012, 'O ano de lançamento do álbum é obrigatório');
        WHEN excecao_artista_null THEN
            RAISE_APPLICATION_ERROR(-20013, 'O artista que interpreta o álbum é obrigatório');
        WHEN excecao_suporte_null THEN
            RAISE_APPLICATION_ERROR(-20014, 'O suporte do álbum é obrigatório');
        
        WHEN OTHERS THEN 
            IF SQLCODE = -2290 THEN   
                IF SQLERRM LIKE '%CK_VERSAO_EAN%' THEN   
                    RAISE_APPLICATION_ERROR(-20015, 'O código EAN-13 de um álbum deve ser constituido por 13 dígitos');
                ELSIF SQLERRM LIKE '%CK_ALBUM_TIPO%' THEN   
                    RAISE_APPLICATION_ERROR(-20016, 'O tipo do álbum tem de ser single, EP ou LP');
                ELSIF SQLERRM LIKE '%CK_ALBUM_ANO%' THEN   
                    RAISE_APPLICATION_ERROR(-20017, 'O ano de um álbum tem de ser igual ou posterior a 1900');
                ELSIF SQLERRM LIKE '%CK_ALBUM_SUPORTE%' THEN   
                    RAISE_APPLICATION_ERROR(-20018, 'O suporte do álbum tem de ser CD, vinil ou cassete');
                END IF;
            ELSE
                DBMS_OUTPUT.PUT_LINE('Erro inesperado: ' || SQLERRM);
                RAISE;
            END IF;
    END regista_album;

    -- ----------------------------------------------------------------------------------------------

    PROCEDURE regista_utilizador (
        username_in     IN utilizador.username%TYPE, 
        email_in        IN utilizador.email%TYPE, 
        senha_in        IN utilizador.senha%TYPE, 
        nascimento_in   IN utilizador.nascimento%TYPE, 
        artista_in      IN utilizador.artista%TYPE := NULL)
    IS
        ano NUMBER;
        excecao_nao_artista EXCEPTION;
        excecao_idade EXCEPTION;

        excecao_username_null EXCEPTION;
        excecao_email_null EXCEPTION;
        excecao_senha_null EXCEPTION;
        excecao_nascimento_null EXCEPTION;
    BEGIN
        IF username_in IS NULL THEN
            RAISE excecao_username_null;
        ELSIF email_in IS NULL THEN
            RAISE excecao_email_null;
        ELSIF senha_in IS NULL THEN
            RAISE excecao_senha_null;
        ELSIF nascimento_in IS NULL THEN
            RAISE excecao_nascimento_null;
        END IF;

        IF artista_in IS NOT NULL AND NOT existe_artista(artista_in) THEN
            RAISE excecao_nao_artista;
        END IF;
            
        ano := EXTRACT(YEAR FROM SYSDATE);

        -- Verifica se o utilizador tem pelo menos 13 anos
        IF (ano - nascimento_in < 13) THEN
            RAISE excecao_idade;
        END IF;
            
        INSERT INTO utilizador(username, email, senha, nascimento, artista) 
            VALUES(username_in, email_in, senha_in, nascimento_in, artista_in);

    EXCEPTION
        WHEN excecao_idade THEN 
            RAISE_APPLICATION_ERROR(-20019, 'O utilizador tem de ter 13 ou mais anos');
        WHEN excecao_nao_artista THEN
            RAISE_APPLICATION_ERROR(-20020, 'Não foram encontrados artistas com este código ISNI ' || artista_in);    

        WHEN excecao_username_null THEN
            RAISE_APPLICATION_ERROR(-20021, 'O username do utilizador é obrigatório');
        WHEN excecao_email_null THEN
            RAISE_APPLICATION_ERROR(-20022, 'O email do utilizador é obrigatório');
        WHEN excecao_senha_null THEN
            RAISE_APPLICATION_ERROR(-20023, 'A senha do utilizador é obrigatório');
        WHEN excecao_nascimento_null THEN
            RAISE_APPLICATION_ERROR(-20024, 'O ano de nascimento do utilizador é obrigatório');

        WHEN OTHERS THEN
            IF SQLCODE = -1 THEN   
                IF SQLERRM LIKE '%PK_UTILIZADOR%' THEN   
                    RAISE_APPLICATION_ERROR(-20025, 'Já existe um utilizador com username ' || username_in);
                ELSIF SQLERRM LIKE '%UN_UTILIZADOR_EMAIL%' THEN   
                    RAISE_APPLICATION_ERROR(-20026, 'O email ' || email_in || ' já está a ser utilizado');
                END IF;
            ELSIF SQLCODE = -2290 THEN   
                IF SQLERRM LIKE '%CK_UTILIZADOR_USERNAME%' THEN   
                    RAISE_APPLICATION_ERROR(-20027, 'O nome de utilizador só pode conter letras e/ou dígitos');
                ELSIF SQLERRM LIKE '%CK_UTILIZADOR_NASCIMENTO%' THEN   
                    RAISE_APPLICATION_ERROR(-20028, 'O utilizador não pode ter data de nascimento anterior a 1900');
                END IF;
            ELSE
                DBMS_OUTPUT.PUT_LINE('Erro inesperado: ' || SQLERRM);
                RAISE;
            END IF;
    END regista_utilizador;

    -- ----------------------------------------------------------------------------------------------

    FUNCTION regista_posse ( 
        utilizador_in   IN possui.utilizador%TYPE, 
        album_in        IN possui.album%TYPE, 
        desde_in        IN possui.desde%TYPE := SYSDATE)
        RETURN NUMBER
    IS
        ano_posse album.ano%TYPE;
        ano_lancamento album.ano%TYPE;
        ano_nascimento utilizador.nascimento%TYPE;
        
        excecao_data_posse EXCEPTION;
        excecao_idade EXCEPTION;
        excecao_nao_utilizador EXCEPTION;
        excecao_nao_album EXCEPTION;
        
        excecao_utilizador_null EXCEPTION;
        excecao_album_null EXCEPTION;
        excecao_desde_null EXCEPTION;

    BEGIN
        IF utilizador_in IS NULL THEN
            RAISE excecao_utilizador_null;
        ELSIF album_in IS NULL THEN
            RAISE excecao_album_null;
        ELSIF desde_in IS NULL THEN
            RAISE excecao_desde_null;
        END IF;
        
        IF NOT existe_utilizador(utilizador_in) THEN
            RAISE excecao_nao_utilizador;
        
        ELSIF NOT existe_album(album_in) THEN
            RAISE excecao_nao_album;
        END IF;
        
        ano_posse := EXTRACT(YEAR FROM desde_in);
        
        SELECT ano INTO ano_lancamento 
        FROM album 
        WHERE album.ean = album_in;

        SELECT nascimento INTO ano_nascimento 
        FROM utilizador 
        WHERE utilizador.username = utilizador_in;
        
        -- Verifica se o ano da data de posse é posterior ao ano de lançamento do álbum 
        IF (ano_posse < ano_lancamento) THEN
            RAISE excecao_data_posse;
        END IF;

        -- Verifica se o utilizador tinha pelo menos 13 anos na data da posse
        IF (ano_posse - ano_nascimento) < 13 THEN
            RAISE excecao_idade;
        END IF;
        
        INSERT INTO possui(utilizador, album, desde)
            VALUES(utilizador_in, album_in, desde_in);
            
        RETURN posses_utilizador(utilizador_in);
        
    EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN
            RAISE_APPLICATION_ERROR(-20029, 'O utilizador com username ' || utilizador_in || ' já possui o álbum com código EAN-13 ' || album_in);        
        WHEN excecao_idade THEN 
            RAISE_APPLICATION_ERROR(-20030, 'O utilizador tem de ter 13 ou mais anos de idade na data da posse');
        WHEN excecao_data_posse THEN 
            RAISE_APPLICATION_ERROR(-20031, 'O ano da posse do álbum tem de ser posterior ou igual à data de lançamento do mesmo');
        WHEN excecao_nao_utilizador THEN   
            RAISE_APPLICATION_ERROR(-20032, 'Não foram encontrados utilizadores com username ' || utilizador_in);
        WHEN excecao_nao_album THEN   
            RAISE_APPLICATION_ERROR(-20033, 'Não foram encontrados álbuns com código EAN-13 ' || album_in);
        
        WHEN excecao_utilizador_null THEN
            RAISE_APPLICATION_ERROR(-20034, 'O utilizador do registo de posse é obrigatório');
        WHEN excecao_album_null THEN
            RAISE_APPLICATION_ERROR(-20035, 'O álbum do registo de posse é obrigatório');
        WHEN excecao_desde_null THEN
            RAISE_APPLICATION_ERROR(-20036, 'A data do registo de posse é obrigatória. Deixe em branco para a data atual ou preencha com uma data específica');

        WHEN OTHERS THEN RAISE;
            IF SQLCODE = -2290 THEN   
                -- Unreachable code. Deixamos no caso de sermos descontados por não implementar
                RAISE_APPLICATION_ERROR(-20037, 'Um utilizador só pode possuir álbuns a partir de 01.01.1900');
            ELSE
                DBMS_OUTPUT.PUT_LINE('Erro inesperado: ' || SQLERRM);
                RAISE;
            END IF;
    END regista_posse;

    -- ----------------------------------------------------------------------------------------------

    FUNCTION remove_posse ( 
        utilizador_in   IN possui.utilizador%TYPE, 
        album_in        IN possui.album%TYPE)
        RETURN NUMBER
    IS
        n_albuns NUMBER;
        excecao_nao_utilizador EXCEPTION;
        excecao_nao_album EXCEPTION;
        
        excecao_utilizador_null EXCEPTION;
        excecao_album_null EXCEPTION;
    BEGIN
        -- Verifica se o utilizador e o álbum da posse a remover existem
        IF utilizador_in IS NULL THEN
            RAISE excecao_utilizador_null;
        ELSIF album_in IS NULL THEN
            RAISE excecao_album_null;
        ELSIF NOT existe_utilizador(utilizador_in) THEN
            RAISE excecao_nao_utilizador;
        ELSIF NOT existe_album(album_in) THEN
            RAISE excecao_nao_album;
        END IF;

        -- Remove o album da coleção do utilizador
        DELETE FROM possui
        WHERE possui.utilizador = utilizador_in
        AND possui.album = album_in;

        -- Verifica se foi possível remover a posse
        IF SQL%ROWCOUNT = 0 THEN
            DBMS_OUTPUT.PUT_LINE('Não foi encontrada nehuma entrada para remover');
        ELSE 
            DBMS_OUTPUT.PUT_LINE('O álbum ' || album_in || ' foi removido da coleção do utilizador com username ' || utilizador_in);
        END IF;  

        RETURN posses_utilizador(utilizador_in);
        
    EXCEPTION
        WHEN excecao_nao_utilizador THEN
            RAISE_APPLICATION_ERROR(-20038, 'Não foram encontrados utilizadores com username ' || utilizador_in);
        WHEN excecao_nao_album THEN
            RAISE_APPLICATION_ERROR(-20039, 'Não foram encontrados álbuns com código EAN-13 ' || album_in);
        WHEN excecao_utilizador_null THEN
            RAISE_APPLICATION_ERROR(-20040, 'O utilizador do registo de posse é obrigatório');
        WHEN excecao_album_null THEN
            RAISE_APPLICATION_ERROR(-20041, 'O álbum do registo de posse é obrigatório');

        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('Erro inesperado: ' || SQLERRM);
            RAISE;
    END remove_posse;

    -- ----------------------------------------------------------------------------------------------

    PROCEDURE remove_utilizador(
        username_in IN utilizador.username%TYPE)
    IS
        -- Cursor com todos os álbuns do utilizador 
        CURSOR c_posses_utilizador IS 
            SELECT * FROM possui WHERE possui.utilizador = username_in;
            
        -- variável usada para descartar os valores devolvidos por remove_posse
        bin NUMBER; 
            
        excecao_nao_utilizador EXCEPTION;             
        excecao_username_null EXCEPTION;         
    BEGIN
        -- Verifica se o utilizador a remover existe
        IF username_in IS NULL THEN
            RAISE excecao_username_null;
        ELSIF NOT existe_utilizador(username_in) THEN
            RAISE excecao_nao_utilizador;
        END IF;
        
        -- Remove todos os álbuns da coleção do utilizador
        FOR posse IN c_posses_utilizador LOOP
            bin := remove_posse(posse.utilizador, posse.album);
        END LOOP;

        DELETE FROM utilizador 
        WHERE utilizador.username = username_in;

        -- Antes tinhamos SQL%NOTFOUND e mudámos para SQL%ROWCOUNT = 0. não conseguimos testar o que alterámos por problemas com o servidor da faculdade desde as 4 da tarde
        IF SQL%ROWCOUNT = 0 THEN -- Código redundante, deixamos no caso de sermos descontados por não implementar
            DBMS_OUTPUT.PUT_LINE('Não foi encontrada nehuma entrada para remover');
        ELSE 
            DBMS_OUTPUT.PUT_LINE('O utilizador e todos os seus álbuns foram removidos com sucesso');
        END IF;
    EXCEPTION

        WHEN excecao_username_null THEN
            RAISE_APPLICATION_ERROR(-20042, 'O username do utilizador é obrigatório');
            
        WHEN excecao_nao_utilizador THEN
            RAISE_APPLICATION_ERROR(-20043, 'O utilizador com username ' || username_in || ' não existe');
        WHEN OTHERS THEN RAISE;
            DBMS_OUTPUT.PUT_LINE('Erro inesperado: ' || SQLERRM);
            RAISE;
    END remove_utilizador;

    -- ----------------------------------------------------------------------------------------------

    PROCEDURE remove_album (
        ean_in IN possui.album%TYPE)
    IS
        -- Cursor com todos os utilizadores que têm o album com ean_in
        CURSOR c_album_utilizadores IS
            SELECT utilizador FROM possui WHERE possui.album = ean_in;
            
        -- variável usada para descartar os valores devolvidos por remove_posse
        bin NUMBER;
        
        excecao_nao_album EXCEPTION;
        excecao_ean_null EXCEPTION;           
    BEGIN
        -- Verifica se o álbum a remover existe
        IF ean_in IS NULL THEN
            RAISE excecao_ean_null; 
        ELSIF NOT existe_album(ean_in) THEN
            RAISE excecao_nao_album;
        END IF;

        -- Remove o álbum de todas as coleções em que está contido
        FOR u IN c_album_utilizadores LOOP
            bin := remove_posse(u.utilizador, ean_in);
        END LOOP;

        DELETE FROM album
        WHERE album.ean = ean_in;
        
        -- Antes tinhamos SQL%NOTFOUND e mudámos para SQL%ROWCOUNT = 0. não conseguimos testar o que alterámos por problemas com o servidor da faculdade desde as 4 da tarde
        IF SQL%ROWCOUNT = 0 THEN -- Código redundante, deixamos no caso de sermos descontados por não implementar
            DBMS_OUTPUT.PUT_LINE('Não foi encontrada nehuma entrada para remover');
        ELSE 
            DBMS_OUTPUT.PUT_LINE('O álbum e todas as suas ocorrências foram removidos');
        END IF;

    EXCEPTION
        WHEN excecao_nao_album THEN
            RAISE_APPLICATION_ERROR(-20044, 'Não existe álbum com código EAN-13 ' || ean_in);
        WHEN excecao_ean_null THEN
            RAISE_APPLICATION_ERROR(-20045, 'O código EAN-13 do álbum é obrigatório');
        WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('Erro inesperado: ' || SQLERRM);
            RAISE;
    END remove_album;

    -- ----------------------------------------------------------------------------------------------

    PROCEDURE remove_artista (
        isni_in IN artista.isni%TYPE)
    IS
        -- Cursor com todos os álbuns interpretados pelo artista
        CURSOR c_albuns_artista IS
            SELECT ean FROM album WHERE isni_in = album.artista;
        
        excecao_nao_artista EXCEPTION;
        excecao_isni_null EXCEPTION;

    BEGIN
        -- Verifica se o artista a remover existe
        IF isni_in IS NULL THEN
            RAISE excecao_isni_null;
        ELSIF NOT existe_artista (isni_in) THEN
            RAISE excecao_nao_artista;
        END IF;

        -- Remove todos os álbuns interpretados pelo artista
        FOR album IN c_albuns_artista LOOP
            remove_album (album.ean);
        END LOOP;  
        
        -- Remove o artista dos favoritos dos utilizadores associados
        FOR utilizador IN (SELECT username FROM utilizador WHERE utilizador.artista = isni_in) LOOP
            UPDATE utilizador 
            SET utilizador.artista = NULL
            WHERE utilizador.artista = isni_in;
        END LOOP;

        DELETE FROM artista
        WHERE artista.isni = isni_in;
        
        -- Antes tinhamos SQL%NOTFOUND e mudámos para SQL%ROWCOUNT = 0. não conseguimos testar o que alterámos por problemas com o servidor da faculdade desde as 4 da tarde
        IF SQL%ROWCOUNT = 0 THEN -- Código redundante, deixamos no caso de sermos descontados por não implementar
            DBMS_OUTPUT.PUT_LINE('Não foi encontrada nehuma entrada para remover');
        ELSE 
            DBMS_OUTPUT.PUT_LINE('O artista e todos os seus álbuns foram removidos com sucesso');
        END IF;

    EXCEPTION
        WHEN excecao_nao_artista THEN
            RAISE_APPLICATION_ERROR(-20046, 'Não existe artista com código ISNI ' || isni_in);
        WHEN excecao_isni_null THEN
            RAISE_APPLICATION_ERROR(-20047, 'O código ISNI do artista é obrigatório');
        WHEN OTHERS THEN RAISE;
            DBMS_OUTPUT.PUT_LINE('Erro inesperado: ' || SQLERRM);
            RAISE;
    END remove_artista;

    -- ----------------------------------------------------------------------------------------------

    FUNCTION lista_albuns (
        utilizador_in IN possui.utilizador%TYPE)
        RETURN SYS_REFCURSOR
    IS
        c_albuns SYS_REFCURSOR;
        
        excecao_nao_utilizador EXCEPTION;
        excecao_utilizador_null EXCEPTION;

    BEGIN
        IF utilizador_in IS NULL THEN
            RAISE excecao_utilizador_null;
        ELSIF NOT existe_utilizador(utilizador_in) THEN
            RAISE excecao_nao_utilizador;
        ELSE
            OPEN c_albuns FOR
                SELECT AL.ean,
                    AL.titulo,
                    AL.tipo,
                    AL.ano,
                    AL.suporte,
                    AL.versao,  
                    AL.artista || DECODE(AL.artista, UT.artista, '*', '') AS artista
                FROM album AL, possui PO, utilizador UT
                WHERE (PO.utilizador = utilizador_in)
                AND   (PO.album = AL.ean)
                AND   (UT.username = PO.utilizador)
                ORDER BY ano DESC, artista ASC, titulo ASC;
            RETURN c_albuns;
        END IF;
        
    EXCEPTION
        WHEN excecao_utilizador_null THEN
            RAISE_APPLICATION_ERROR(-20048, 'O username do utilizador é obrigatório');
        WHEN excecao_nao_utilizador THEN
            RAISE_APPLICATION_ERROR(-20049, 'Não existe utilizador com username ' || utilizador_in);
        WHEN OTHERS THEN RAISE;
            DBMS_OUTPUT.PUT_LINE('Erro inesperado: ' || SQLERRM);
            RAISE;
    END lista_albuns;

END pkg_colecao;
/