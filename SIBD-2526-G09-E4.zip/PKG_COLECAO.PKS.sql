-- ----------------------------------------------------------------------------
--
-- LEI - Etapa 4 do projeto - SIBD - 2025/26 - Grupo 09
--
-- Nuno Nunes - nº63731 - TP12
-- Dinis Fernandes - nº63787 - TP14
-- Tiago Wu - nº63696 - TP14
--
-- ----------------------------------------------------------------------------
--
-- User Defined Exceptions
--
-- PROCEDURE regista_artista
--  -20000 Já existe um artista com isni isni_in
--  -20001 O nome do artista é obrigatório
--  -20002 O ano de inicio de atividade do artista é obrigatório
--  -20003 O código ISNI do artista é obrigatório
--  -20004 O código ISNI do artista deve ter exatamente 16 caracteres,
--         sendo composto por 15 dígitos numéricos seguidos por um dígito ou a letra X
--  -20005 O ano de início de atividade do artista tem de ser positivo
--
-- PROCEDURE regista_album
--  -20006 Já existe um álbum com EAN ean_in
--  -20007 O ano de lançamento do álbum tem de ser posterior ou igual ao ano de início de atividade do artista que o interpreta
--  -20008 Não foram encontrados artistas com código ISNI artista_in
--  -20009 O código EAN-13 do álbum é obrigatório
--  -20010 O título do álbum é obrigatório
--  -20011 O tipo do álbum é obrigatório
--  -20012 O ano de lançamento do álbum é obrigatório
--  -20013 O artista que interpreta este álbum é obrigatório
--  -20014 O suporte do álbum é obrigatório
--  -20015 O código EAN-13 de um álbum deve ser constituido por 13 dígitos
--  -20016 O tipo do álbum tem de ser single, EP ou LP
--  -20017 O ano de um álbum tem de ser igual ou posterior a 1900
--  -20018 O suporte do álbum tem de ser CD, vinil ou cassete
--
-- PROCEDURE regista_utilizador
--  -20019 O utilizador tem de ter 13 ou mais anos
--  -20020 Não foram encontrados artistas com código ISNI artista_in
--  -20021 O username do utilizador é obrigatório
--  -20022 O email do utilizador é obrigatório
--  -20023 A senha do utilizador é obrigatório
--  -20024 O ano de nascimento do utilizador é obrigatório
--  -20025 Já existe um utilizador com username username_in
--  -20026 O email email_in já está a ser utilizado
--  -20027 O nome de utilizador só pode conter letras e/ou algarismos
--  -20028 O utilizador não pode ter data de nascimento anterior a 1900
--
-- PROCEDURE regista_posse
--  -20029 O utilizador com username utilizador_in já possui o álbum com código EAN-13 album_in
--  -20030 O utilizador tem de ter 13 ou mais anos de idade na data da posse
--  -20031 O ano da posse do álbum tem de ser posterior ou igual à data de lançamento do mesmo
--  -20032 Não foram encontrados utilizadores com username utilizador_in
--  -20033 Não foram encontrados álbuns com código EAN-13 album_in
--  -20034 O utilizador do registo de posse é obrigatório
--  -20035 O álbum do registo de posse é obrigatório
--  -20036 A data do registo de posse é obrigatória. 
--         Deixe em branco para a data atual ou preencha com uma data específica
--  -20037 Um utilizador só pode possuir álbuns a partir de 01.01.1900
--
-- FUNCTION remove_posse
--  -20038 Não foram encontrados utilizadores com username
--  -20039 Não foram encontrados álbuns com código EAN-13
--  -20040 O utilizador do registo de posse é obrigatório
--  -20041 O álbum do registo de posse é obrigatório
--
-- FUNCTION remove_utilizador
--  -20042 O username do utilizador é obrigatório
--  -20043 O utilizador com username username_in não existe
--
-- PROCEDURE remove_album
--  -20044 Não existe álbum com código EAN-13 ean_in
--  -20045 O código EAN-13 do álbum é obrigatório
--
-- PROCEDURE remove_artista
--  -20046 Não existe artista com código ISNI isni_in
--  -20047 Não existe artista com código ISNI isni_in
--
-- FUNCTION lista_albuns
--  -20048 O username do utilizador é obrigatório
--  -20049 Não existe utilizador com username utilizador_in
--
-- ----------------------------------------------------------------------------


CREATE OR REPLACE PACKAGE pkg_colecao IS

    PROCEDURE regista_artista (
        isni_in     IN artista.isni%TYPE, 
        nome_in     IN artista.nome%TYPE, 
        inicio_in   IN artista.inicio%TYPE);

    PROCEDURE regista_album (
        ean_in      IN album.ean%TYPE, 
        titulo_in   IN album.titulo%TYPE, 
        tipo_in     IN album.tipo%TYPE, 
        ano_in      IN album.ano%TYPE, 
        artista_in  IN album.artista%TYPE, 
        suporte_in  IN album.suporte%TYPE, 
        versao_in   IN album.versao%TYPE := NULL);

    PROCEDURE regista_utilizador (
        username_in     IN utilizador.username%TYPE, 
        email_in        IN utilizador.email%TYPE, 
        senha_in        IN utilizador.senha%TYPE, 
        nascimento_in   IN utilizador.nascimento%TYPE, 
        artista_in      IN utilizador.artista%TYPE := NULL);

    FUNCTION regista_posse ( 
        utilizador_in   IN possui.utilizador%TYPE, 
        album_in        IN possui.album%TYPE, 
        desde_in        IN possui.desde%TYPE := SYSDATE)
        RETURN NUMBER;

    FUNCTION remove_posse (
        utilizador_in   IN possui.utilizador%TYPE, 
        album_in        IN possui.album%TYPE)
        RETURN NUMBER;

    PROCEDURE remove_utilizador (
        username_in IN utilizador.username%TYPE);

    PROCEDURE remove_album (
        ean_in IN possui.album%TYPE);

    PROCEDURE remove_artista (
        isni_in IN artista.isni%TYPE);

    FUNCTION lista_albuns (
        utilizador_in IN possui.utilizador%TYPE)
        RETURN SYS_REFCURSOR; 

END pkg_colecao;
/