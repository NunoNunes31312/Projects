-- ----------------------------------------------------------------------------
--
-- LEI - Etapa 4 do projeto - SIBD - 2025/26 - Grupo 09
--
-- Nuno Nunes - nº63731 - TP12
-- Dinis Fernandes - nº63787 - TP14
-- Tiago Wu - nº63696 - TP14
--
-- ----------------------------------------------------------------------------
--
-- Contribuições:
-- Nuno Nunes - 26% - formulação inicial do código, ajuda nos testes de demonstração, revisão final do código
-- Dinis Fernandes - 37% - limpeza do código e formatação, realização dos testes de demonstração, realização de exceções e código auxiliar relacionado, correção de erros, revisão final do código
-- Tiago Wu - 37% - formulação inicial do código, formatação do código, verificação de exceções, ajuda nos testes de demonstração, revisão final do código 
--
-- ----------------------------------------------------------------------------

-- Script de Demonstração

DELETE FROM possui;
DELETE FROM utilizador;
DELETE FROM album;
DELETE FROM artista;

-- ------------------------------------------------------------------------------------------------
-- regista_artista
-- ------------------------------------------------------------------------------------------------

-- registo válido
BEGIN pkg_colecao.regista_artista(isni_in => '1111111111111111',
                                  nome_in => 'artista1',
                                  inicio_in => 2000);
END;
/

-- registo válido
BEGIN pkg_colecao.regista_artista(isni_in => '2222222222222222',
                                  nome_in => 'artista2',
                                  inicio_in => 1800);
END;
/

-- registo inválido: ISNI repetido
BEGIN pkg_colecao.regista_artista(isni_in => '1111111111111111',
                                  nome_in => 'artista1',
                                  inicio_in => 2000);
END;
/

-- registo inválido: um dos caracteres do ISNI não é um dígito
BEGIN pkg_colecao.regista_artista(isni_in => '11111111111111A1',
                                  nome_in => 'artista1',
                                  inicio_in => 2000);
END;
/

-- registo inválido: ano de início < 0
BEGIN pkg_colecao.regista_artista(isni_in => '1111111111111111',
                                  nome_in => 'artista1',
                                  inicio_in => -2000);
END;
/

-- registo inválido: nome NULL
BEGIN pkg_colecao.regista_artista(isni_in => '2222222222222222',
                                  nome_in => NULL,
                                  inicio_in => 2000);
END;
/

-- registo inválido: início NULL
BEGIN pkg_colecao.regista_artista(isni_in => '2222222222222222',
                                  nome_in => 'artista2',
                                  inicio_in => NULL);
END;
/

-- registo inválido: isni NULL
BEGIN pkg_colecao.regista_artista(isni_in => NULL,
                                  nome_in => 'artista2',
                                  inicio_in => '2000');
END;
/

SELECT * FROM artista;

-- ------------------------------------------------------------------------------------------------
-- regista_album
-- ------------------------------------------------------------------------------------------------

-- registo válido
BEGIN pkg_colecao.regista_album(ean_in => '0000000000001',
                                titulo_in => 'album1',
                                tipo_in => 'single',
                                ano_in => '2000',
                                artista_in => '1111111111111111',
                                suporte_in => 'CD',
                                versao_in => 'versao1');
END;
/

-- registo válido
BEGIN pkg_colecao.regista_album(ean_in => '0000000000002',
                                titulo_in => 'album2',
                                tipo_in => 'EP',
                                ano_in => '2000',
                                artista_in => '1111111111111111',
                                suporte_in => 'CD',
                                versao_in => 'versao1');
END;
/

-- registo válido
BEGIN pkg_colecao.regista_album(ean_in => '0000000000003',
                                titulo_in => 'album3',
                                tipo_in => 'EP',
                                ano_in => '2000',
                                artista_in => '1111111111111111',
                                suporte_in => 'CD',
                                versao_in => 'versao1');
END;
/

-- registo inválido: EAN-13 já existente
BEGIN pkg_colecao.regista_album(ean_in => '0000000000001',
                                titulo_in => 'album1',
                                tipo_in => 'single',
                                ano_in => '2000',
                                artista_in => '1111111111111111',
                                suporte_in => 'CD',
                                versao_in => 'versao1');
END;
/

-- registo inválido: ano de lançamento < ano de inicio do artista
BEGIN pkg_colecao.regista_album(ean_in => '0000000000003',
                                titulo_in => 'album3',
                                tipo_in => 'single',
                                ano_in => '1999',
                                artista_in => '1111111111111111',
                                suporte_in => 'CD',
                                versao_in => 'versao1');
END;
/

-- registo inválido: um dos caracteres do EAN-13 não é um dígito
BEGIN pkg_colecao.regista_album(ean_in => '00000000A0001',
                                titulo_in => 'album1',
                                tipo_in => 'single',
                                ano_in => '2000',
                                artista_in => '1111111111111111',
                                suporte_in => 'CD',
                                versao_in => 'versao1');
END;
/

-- registo inválido: tipo do álbum não está correto
BEGIN pkg_colecao.regista_album(ean_in => '0000000000001',
                                titulo_in => 'album1',
                                tipo_in => 'singl',
                                ano_in => '2000',
                                artista_in => '1111111111111111',
                                suporte_in => 'CD',
                                versao_in => 'versao1');
END;
/

-- registo inválido: ano < 1900
BEGIN pkg_colecao.regista_album(ean_in => '0000000000001',
                                titulo_in => 'album1',
                                tipo_in => 'single',
                                ano_in => '1850',
                                artista_in => '2222222222222222',
                                suporte_in => 'CD',
                                versao_in => 'versao1');
END;
/

-- registo inválido: suporte do álbum não está correto
BEGIN pkg_colecao.regista_album(ean_in => '0000000000001',
                                titulo_in => 'album1',
                                tipo_in => 'single',
                                ano_in => '2000',
                                artista_in => '1111111111111111',
                                suporte_in => 'CF',
                                versao_in => 'versao1');
END;
/

-- registo inválido: não existe artista com este isni
BEGIN pkg_colecao.regista_album(ean_in => '0000000000001',
                                titulo_in => 'album1',
                                tipo_in => 'single',
                                ano_in => '2000',
                                artista_in => '7089314554897342',
                                suporte_in => 'CD',
                                versao_in => 'versao1');
END;
/

-- registo inválido: suporte NULL
BEGIN pkg_colecao.regista_album(ean_in => '0000000000001',
                                titulo_in => 'album1',
                                tipo_in => 'single',
                                ano_in => '2000',
                                artista_in => '1111111111111111',
                                suporte_in => NULL,
                                versao_in => 'versao1');
END;
/

-- registo inválido: artista NULL
BEGIN pkg_colecao.regista_album(ean_in => '0000000000001',
                                titulo_in => 'album1',
                                tipo_in => 'single',
                                ano_in => '2000',
                                artista_in => NULL,
                                suporte_in => 'CD',
                                versao_in => 'versao1');
END;
/

-- registo inválido: ano NULL
BEGIN pkg_colecao.regista_album(ean_in => '0000000000001',
                                titulo_in => 'album1',
                                tipo_in => 'single',
                                ano_in => NULL,
                                artista_in => '1111111111111111',
                                suporte_in => 'CD',
                                versao_in => 'versao1');
END;
/

-- registo inválido: tipo NULL
BEGIN pkg_colecao.regista_album(ean_in => '0000000000001',
                                titulo_in => 'album1',
                                tipo_in => NULL,
                                ano_in => '2000',
                                artista_in => '1111111111111111',
                                suporte_in => 'CD',
                                versao_in => 'versao1');
END;
/

-- registo inválido: titulo NULL
BEGIN pkg_colecao.regista_album(ean_in => '0000000000001',
                                titulo_in => NULL,
                                tipo_in => 'single',
                                ano_in => '2000',
                                artista_in => '1111111111111111',
                                suporte_in => 'CD',
                                versao_in => 'versao1');
END;
/

-- registo inválido: ean NULL
BEGIN pkg_colecao.regista_album(ean_in => NULL,
                                titulo_in => 'album1',
                                tipo_in => 'single',
                                ano_in => '2000',
                                artista_in => '1111111111111111',
                                suporte_in => 'CD',
                                versao_in => 'versao1');
END;
/

SELECT * FROM album;

-- ------------------------------------------------------------------------------------------------
-- regista_utilizador
-- ------------------------------------------------------------------------------------------------

-- registo válido
BEGIN pkg_colecao.regista_utilizador(username_in => 'user1',
                                     email_in => 'user1@gmail.com',
                                     senha_in => 'senha',
                                     nascimento_in => '2000',
                                     artista_in => '1111111111111111');
END;
/

-- registo válido
BEGIN pkg_colecao.regista_utilizador(username_in => 'user2',
                                     email_in => 'user2@gmail.com',
                                     senha_in => 'senha',
                                     nascimento_in => '2000',
                                     artista_in => NULL);
END;
/

-- registo inválido: username já existente
BEGIN pkg_colecao.regista_utilizador(username_in => 'user1',
                                     email_in => 'user1@gmail.com',
                                     senha_in => 'senha',
                                     nascimento_in => '2000',
                                     artista_in => '1111111111111111');
END;
/

-- registo inválido: idade < 13 
BEGIN pkg_colecao.regista_utilizador(username_in => 'user2',
                                     email_in => 'user2@gmail.com',
                                     senha_in => 'senha',
                                     nascimento_in => '2020',
                                     artista_in => '1111111111111111');
END;
/

-- registo inválido: email já em utilização
BEGIN pkg_colecao.regista_utilizador(username_in => 'user3',
                                     email_in => 'user1@gmail.com',
                                     senha_in => 'senha',
                                     nascimento_in => '2000',
                                     artista_in => '1111111111111111');
END;
/

-- registo válido: NOTA: username contém um símbolo. Segundo o RIA-14, caracteres 
-- para além de letras e dígitos não deviam ser permitidos. Pensamos ser um erro das tabelas

BEGIN pkg_colecao.regista_utilizador(username_in => 'user-3',
                                     email_in => 'user3@gmail.com',
                                     senha_in => 'senha',
                                     nascimento_in => '2000',
                                     artista_in => '1111111111111111');
END;
/

-- registo inválido: ano de nascimento anterior a 1900
BEGIN pkg_colecao.regista_utilizador(username_in => 'user4',
                                     email_in => 'user4@gmail.com',
                                     senha_in => 'senha',
                                     nascimento_in => '1899',
                                     artista_in => '1111111111111111');
END;
/

-- registo inválido: não existe artista com este isni
BEGIN pkg_colecao.regista_utilizador(username_in => 'user5',
                                     email_in => 'user5@gmail.com',
                                     senha_in => 'senha',
                                     nascimento_in => '2000',
                                     artista_in => '7089314554897342');
END;
/

-- registo inválido: nascimento NULL
BEGIN pkg_colecao.regista_utilizador(username_in => 'user5',
                                     email_in => 'user5@gmail.com',
                                     senha_in => 'senha',
                                     nascimento_in => NULL,
                                     artista_in => '1111111111111111');
END;
/

-- registo inválido: senha NULL
BEGIN pkg_colecao.regista_utilizador(username_in => 'user5',
                                     email_in => 'user5@gmail.com',
                                     senha_in => NULL,
                                     nascimento_in => '2000',
                                     artista_in => '1111111111111111');
END;
/

-- registo inválido: email NULL
BEGIN pkg_colecao.regista_utilizador(username_in => 'user5',
                                     email_in => NULL,
                                     senha_in => 'senha',
                                     nascimento_in => '2000',
                                     artista_in => '1111111111111111');
END;
/

-- registo inválido: username NULL
BEGIN pkg_colecao.regista_utilizador(username_in => NULL,
                                     email_in => 'user5@gmail.com',
                                     senha_in => 'senha',
                                     nascimento_in => '2000',
                                     artista_in => '1111111111111111');
END;
/

SELECT * FROM utilizador;

-- ------------------------------------------------------------------------------------------------
-- regista_posse
-- ------------------------------------------------------------------------------------------------

VARIABLE albuns_count NUMBER;

-- registo válido
BEGIN :albuns_count := pkg_colecao.regista_posse('user1', '0000000000001'); END;
/
PRINT albuns_count;

-- registo válido
BEGIN :albuns_count := pkg_colecao.regista_posse('user1', '0000000000002', TO_DATE('01-01-2020', 'DD-MM-YYYY')); END;
/
PRINT albuns_count;

-- registo inválido: utilizador já possui este álbum  
BEGIN :albuns_count := pkg_colecao.regista_posse('user1', '0000000000001', TO_DATE('01-01-2020', 'DD-MM-YYYY')); END;
/
PRINT albuns_count;

-- registo inválido: data de posse < 1900 
BEGIN :albuns_count := pkg_colecao.regista_posse('user1', '0000000000003', TO_DATE('01-01-1890', 'DD-MM-YYYY')); END;
/
PRINT albuns_count;

-- registo inválido: utilizador tinha menos de 13 anos na data de posse
BEGIN :albuns_count := pkg_colecao.regista_posse('user1', '0000000000003', TO_DATE('01-01-2005', 'DD-MM-YYYY')); END;
/
PRINT albuns_count;

-- registo inválido: data de posse < data de lançamento do álbum
BEGIN :albuns_count := pkg_colecao.regista_posse('user1', '0000000000003', TO_DATE('01-01-1999', 'DD-MM-YYYY')); END;
/
PRINT albuns_count;

-- registo inválido: não existe utilizador com este username
BEGIN :albuns_count := pkg_colecao.regista_posse('user50', '0000000000003'); END;
/
PRINT albuns_count;

-- registo inválido: não existe álbum com este código EAN-13
BEGIN :albuns_count := pkg_colecao.regista_posse('user1', '36498710354083'); END;
/
PRINT albuns_count;

-- registo inválido: utilizador NULL
BEGIN :albuns_count := pkg_colecao.regista_posse(NULL, '0000000000001'); END;
/
PRINT albuns_count;

-- registo inválido: álbum NULL
BEGIN :albuns_count := pkg_colecao.regista_posse('user1', NULL); END;
/
PRINT albuns_count;

-- registo inválido: data de posse NULL
BEGIN :albuns_count := pkg_colecao.regista_posse('user1', '0000000000001', NULL); END;
/
PRINT albuns_count;

SELECT * FROM possui;

-- ------------------------------------------------------------------------------------------------
-- correr antes dos seguintes testes se não tiver sido corrido anteriormente
VARIABLE albuns_count NUMBER;
-- ------------------------------------------------------------------------------------------------
-- remove_posse
-- ------------------------------------------------------------------------------------------------

-- CORRER ANTES
DELETE FROM possui;
DELETE FROM utilizador;
DELETE FROM album;
DELETE FROM artista;

-- remoção válida
BEGIN pkg_colecao.regista_utilizador(username_in => 'user10',
                                     email_in => 'user10@gmail.com',
                                     senha_in => 'senha',
                                     nascimento_in => '2000');
END;
/

BEGIN pkg_colecao.regista_artista(isni_in => '1010101010101010',
                                  nome_in => 'artista10',
                                  inicio_in => 2000);
END;
/

BEGIN pkg_colecao.regista_album(ean_in => '0000000000010',
                                titulo_in => 'album10',
                                tipo_in => 'EP',
                                ano_in => '2000',
                                artista_in => '1010101010101010',
                                suporte_in => 'CD',
                                versao_in => 'versao1');
END;
/

BEGIN :albuns_count := pkg_colecao.regista_posse('user10', '0000000000010'); END;
/
PRINT albuns_count;

select * from possui; -- tabela das posses antes da remoção

BEGIN :albuns_count := pkg_colecao.remove_posse('user10', '0000000000010'); END;
/
PRINT albuns_count;

select * from possui; -- tabela das posses depois da remoção

-- remoção inválida: não existe entradas para remover
BEGIN :albuns_count := pkg_colecao.remove_posse('user10', '0000000000010'); END;
/
PRINT albuns_count;

-- remoção inválida: não existe utilizador com este username
BEGIN :albuns_count := pkg_colecao.remove_posse('jose', '0000000000010'); END;
/
PRINT albuns_count;

-- remoção inválida: não existe álbum com este código EAN-13
BEGIN :albuns_count := pkg_colecao.remove_posse('user10', '98075623498502'); END;
/
PRINT albuns_count;

-- remoção inválida: utilizador NULL
BEGIN :albuns_count := pkg_colecao.remove_posse(NULL, '0000000000010'); END;
/
PRINT albuns_count;

-- remoção inválida: álbum NULL
BEGIN :albuns_count := pkg_colecao.remove_posse('user10', NULL); END;
/
PRINT albuns_count;

-- ------------------------------------------------------------------------------------------------
-- remove_utilizador
-- ------------------------------------------------------------------------------------------------

-- CORRER ANTES
DELETE FROM possui;
DELETE FROM utilizador;
DELETE FROM album;
DELETE FROM artista;

-- remoção válida
BEGIN pkg_colecao.regista_utilizador(username_in => 'user20',
                                     email_in => 'user20@gmail.com',
                                     senha_in => 'senha',
                                     nascimento_in => '1990');
END;
/

SELECT * FROM utilizador; -- tabela das posses depois da remoção

BEGIN pkg_colecao.remove_utilizador('user20'); END;
/

SELECT * FROM utilizador; -- tabela das posses depois da remoção

-- remoção válida: utilizador com vários álbuns (posses do utilizador também são apagadas)
BEGIN pkg_colecao.regista_utilizador(username_in => 'user20',
                                     email_in => 'user20@gmail.com',
                                     senha_in => 'senha',
                                     nascimento_in => '1990');
END;
/

BEGIN pkg_colecao.regista_artista(isni_in => '2020202020202020',
                                  nome_in => 'artista20',
                                  inicio_in => 2000);
END;
/

BEGIN pkg_colecao.regista_album(ean_in => '0000000000020',
                                titulo_in => 'album20',
                                tipo_in => 'EP',
                                ano_in => '2000',
                                artista_in => '2020202020202020',
                                suporte_in => 'CD',
                                versao_in => 'versao1');
END;
/

BEGIN pkg_colecao.regista_album(ean_in => '0000000000021',
                                titulo_in => 'album20',
                                tipo_in => 'EP',
                                ano_in => '2000',
                                artista_in => '2020202020202020',
                                suporte_in => 'CD',
                                versao_in => 'versao1');
END;
/

BEGIN :albuns_count := pkg_colecao.regista_posse('user20', '0000000000020'); END;
/
PRINT albuns_count;

BEGIN :albuns_count := pkg_colecao.regista_posse('user20', '0000000000021'); END;
/
PRINT albuns_count;

SELECT * FROM utilizador; -- tabelas antes da remoção


BEGIN pkg_colecao.remove_utilizador('user20'); END;
/

SELECT * FROM utilizador; -- tabelas depois da remoção
SELECT * FROM possui;


-- remoção inválida: username null
BEGIN pkg_colecao.remove_utilizador(NULL); END;
/

-- remoção inválida: username não existe 
BEGIN pkg_colecao.remove_utilizador('Maria'); END;
/

-- ------------------------------------------------------------------------------------------------
-- remove_album 
-- ------------------------------------------------------------------------------------------------

-- CORRER ANTES
DELETE FROM possui;
DELETE FROM utilizador;
DELETE FROM album;
DELETE FROM artista;

-- registos apenas para testes de remoção
BEGIN pkg_colecao.regista_artista(isni_in => '3030303030303030',
                                  nome_in => 'artista30',
                                  inicio_in => 2000);
END;
/

BEGIN pkg_colecao.regista_album(ean_in => '3030303030303',
                                titulo_in => 'album30',
                                tipo_in => 'EP',
                                ano_in => '2000',
                                artista_in => '3030303030303030',
                                suporte_in => 'CD',
                                versao_in => 'versao1');
END;
/

BEGIN pkg_colecao.regista_album(ean_in => '3131313131313',
                                titulo_in => 'album31',
                                tipo_in => 'EP',
                                ano_in => '2000',
                                artista_in => '3030303030303030',
                                suporte_in => 'CD',
                                versao_in => 'versao1');
END;
/

BEGIN pkg_colecao.regista_utilizador(username_in => 'user30',
                                     email_in => 'user30@gmail.com',
                                     senha_in => 'senha',
                                     nascimento_in => '2006');
END;
/

BEGIN pkg_colecao.regista_utilizador(username_in => 'user31',
                                     email_in => 'user31@gmail.com',
                                     senha_in => 'senha',
                                     nascimento_in => '2005');
END;
/

BEGIN :albuns_count := pkg_colecao.regista_posse('user30', '3030303030303', TO_DATE('01-01-2020', 'DD-MM-YYYY')); END;
/
PRINT albuns_count;

BEGIN :albuns_count := pkg_colecao.regista_posse('user31', '3131313131313'); END;
/
PRINT albuns_count;

BEGIN :albuns_count := pkg_colecao.regista_posse('user31', '3030303030303'); END;
/
PRINT albuns_count;

select * from album; -- tabelas antes da remoção
select * from possui;

-- remoção válida de álbum que pertence a dois utilizadores
BEGIN pkg_colecao.remove_album('3030303030303'); END;
/

select * from album; -- tabelas depois da primeira remoção
select * from possui;

-- remoção válida de álbum que pertence a um utilizador
BEGIN pkg_colecao.remove_album('3131313131313'); END;
/

select * from album; -- tabelas depois da segunda remoção
select * from possui;

-- remoção inválida: ean NULL
BEGIN pkg_colecao.remove_album(NULL); END;
/

-- remoção inválida: ean não existe
BEGIN pkg_colecao.remove_album('2936785038457'); END;
/

-- ------------------------------------------------------------------------------------------------
-- remove_artista
-- ------------------------------------------------------------------------------------------------

-- CORRER ANTES
DELETE FROM possui;
DELETE FROM utilizador;
DELETE FROM album;
DELETE FROM artista;

-- remoção válida 
BEGIN pkg_colecao.regista_artista(isni_in => '4040404040404040',
                                  nome_in => 'artista40',
                                  inicio_in => 2000);
END;
/

BEGIN pkg_colecao.regista_album(ean_in => '0000000000040',
                                titulo_in => 'album40',
                                tipo_in => 'single',
                                ano_in => '2000',
                                artista_in => '4040404040404040',
                                suporte_in => 'CD',
                                versao_in => 'versao1');
END;
/

BEGIN pkg_colecao.regista_album(ean_in => '0000000000041',
                                titulo_in => 'album41',
                                tipo_in => 'single',
                                ano_in => '2000',
                                artista_in => '4040404040404040',
                                suporte_in => 'CD',
                                versao_in => 'versao1');
END;
/

BEGIN pkg_colecao.regista_utilizador(username_in => 'user40',
                                     email_in => 'user40@gmail.com',
                                     senha_in => 'senha',
                                     nascimento_in => '2006');
END;
/

BEGIN :albuns_count := pkg_colecao.regista_posse('user40', '0000000000041'); END;
/
PRINT albuns_count;

select * from artista; -- tabelas antes da remoção
select * from album;
select * from possui;

BEGIN pkg_colecao.remove_artista('4040404040404040'); END;
/

select * from artista; -- tabelas depois da remoção
select * from album;
select * from possui;


--remoção inválida: artista (isni) não existe
BEGIN pkg_colecao.remove_artista('1234567890123456'); END;
/

--remoção inválida: isni NULL
BEGIN pkg_colecao.remove_artista(NULL);END;
/

-- ------------------------------------------------------------------------------------------------
-- lista albuns
-- ------------------------------------------------------------------------------------------------

-- CORRER ANTES
DELETE FROM possui;
DELETE FROM utilizador;
DELETE FROM album;
DELETE FROM artista;

BEGIN pkg_colecao.regista_artista(isni_in => '5050505050505050',
                                  nome_in => 'artista50',
                                  inicio_in => 2000);
END;
/

BEGIN pkg_colecao.regista_artista(isni_in => '5151515151515151',
                                  nome_in => 'artista51',
                                  inicio_in => 2000);
END;
/

BEGIN pkg_colecao.regista_utilizador(username_in => 'user50',
                                     email_in => 'user50@gmail.com',
                                     senha_in => 'senha',
                                     nascimento_in => '2000',
                                     artista_in => '5151515151515151');
END;
/

BEGIN pkg_colecao.regista_album(ean_in => '0000000000050',
                                titulo_in => 'album50',
                                tipo_in => 'single',
                                ano_in => '2000',
                                artista_in => '5050505050505050',
                                suporte_in => 'CD',
                                versao_in => 'versao1');
END;
/

BEGIN pkg_colecao.regista_album(ean_in => '0000000000051',
                                titulo_in => 'album51',
                                tipo_in => 'single',
                                ano_in => '2000',
                                artista_in => '5151515151515151',
                                suporte_in => 'CD',
                                versao_in => 'versao1');
END;
/

BEGIN pkg_colecao.regista_album(ean_in => '0000000000052',
                                titulo_in => 'album52',
                                tipo_in => 'single',
                                ano_in => '2001',
                                artista_in => '5050505050505050',
                                suporte_in => 'CD',
                                versao_in => 'versao1');
END;
/

BEGIN pkg_colecao.regista_album(ean_in => '0000000000053',
                                titulo_in => 'album53',
                                tipo_in => 'single',
                                ano_in => '2000',
                                artista_in => '5050505050505050',
                                suporte_in => 'CD',
                                versao_in => 'versao1');
END;
/

BEGIN :albuns_count := pkg_colecao.regista_posse('user50', '0000000000050'); END;
/
BEGIN :albuns_count := pkg_colecao.regista_posse('user50', '0000000000051'); END;
/
BEGIN :albuns_count := pkg_colecao.regista_posse('user50', '0000000000052'); END;
/
BEGIN :albuns_count := pkg_colecao.regista_posse('user50', '0000000000053'); END;
/

-- listagem válida dos álbuns do user50
SELECT pkg_colecao.lista_albuns('user50') AS albuns_user50
FROM utilizador;

-- listagem inválida: username NULL
SELECT pkg_colecao.lista_albuns(NULL) AS albuns_user50
FROM utilizador;

--listagem inválida: username não existe
SELECT pkg_colecao.lista_albuns('Josias') AS albuns_user50
FROM utilizador;